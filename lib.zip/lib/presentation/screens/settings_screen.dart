import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../core/constants/subscription_constants.dart';
import '../../providers/theme_provider.dart';
import '../providers/accessibility_provider.dart';
import '../providers/tasa_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isAccessible = ref.watch(accessibilityProvider);
    final prefs = ref.watch(sharedPreferencesProvider);
    final defaultRate = prefs.getString(AppConstants.kPrefDefaultRate) ?? 'BCV USD';
    final decimalFormat = prefs.getString(AppConstants.kPrefDecimalFormat) ?? 'Coma (,)';

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // 5.1 Header
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
              child: Text(
                'Ajustes',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
            ),

            // 5.2 Premium card
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFFE53935),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Text(
                      'TasaVe Premium',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Sin anuncios · Alertas ilimitadas · Widgets',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      onPressed: null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFFE53935),
                      ),
                      child: const Text('Próximamente · \$1.99 pago único'),
                    ),
                  ],
                ),
              ),
            ),

            // 5.3 Preferences section
            _SectionLabel('PREFERENCIAS'),

            _SettingsRow(
              label: 'Tasa por defecto',
              sub: '¿Cuál mostrar primero?',
              value: defaultRate,
              onTap: () => _showDefaultRateSheet(context, ref),
            ),
            _SettingsRow(
              label: 'Formato de número',
              sub: 'Separador decimal',
              value: decimalFormat,
              onTap: () => _showDecimalFormatSheet(context, ref),
            ),
            _SettingsRowToggle(
              label: 'Accesibilidad',
              sub: 'Texto más grande',
              value: isAccessible,
              onTap: () => ref.read(accessibilityProvider.notifier).toggle(),
            ),
            _SettingsRowToggle(
              label: 'Modo oscuro',
              sub: 'Tema oscuro para la app',
              value: ref.watch(themeProvider),
              onTap: () => ref.read(themeProvider.notifier).toggle(),
            ),

            // 5.4 Information section
            _SectionLabel('INFORMACIÓN'),

            _SettingsRow(
              label: 'Fuente de datos',
              value: 'BCV oficial',
              onTap: () => _launchUrl('https://bcv.org.ve'),
            ),
            _SettingsRow(
              label: 'Versión',
              value: '1.0.0 (build 1)',
              showChevron: false,
            ),
            _SettingsRow(
              label: 'Política de privacidad',
              labelColor: AppColors.primary,
              chevronColor: AppColors.primary,
              onTap: () => _launchUrl(SubscriptionConstants.privacyPolicyUrl),
            ),
            _SettingsRow(
              label: 'Contacto / Soporte',
              value: 'soporte@tasave.app',
              onTap: () => _launchUrl('mailto:soporte@tasave.app'),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  void _showDefaultRateSheet(BuildContext context, WidgetRef ref) {
    _showOptionSheet(
      context,
      title: 'Tasa por defecto',
      options: ['BCV USD', 'USDT P2P', 'EUR BCV'],
      onSelected: (value) {
        ref.read(sharedPreferencesProvider).setString(AppConstants.kPrefDefaultRate, value);
        // Force rebuild
        (context as Element).markNeedsBuild();
      },
    );
  }

  void _showDecimalFormatSheet(BuildContext context, WidgetRef ref) {
    _showOptionSheet(
      context,
      title: 'Formato de número',
      options: ['Coma (,)', 'Punto (.)'],
      onSelected: (value) {
        ref.read(sharedPreferencesProvider).setString(AppConstants.kPrefDecimalFormat, value);
        (context as Element).markNeedsBuild();
      },
    );
  }

  void _showOptionSheet(
    BuildContext context, {
    required String title,
    required List<String> options,
    required ValueChanged<String> onSelected,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
              const SizedBox(height: 16),
              ...options.map((opt) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(
                      opt,
                      style: GoogleFonts.dmSans(fontSize: 14, color: AppColors.text),
                    ),
                    onTap: () {
                      onSelected(opt);
                      Navigator.pop(ctx);
                    },
                  )),
            ],
          ),
        );
      },
    );
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }
}

// ─────────────────────────────────────────────────────────────
// SECTION LABEL
// ─────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
      child: Text(
        text,
        style: GoogleFonts.dmSans(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1,
          color: AppColors.text3,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// SETTINGS ROW
// ─────────────────────────────────────────────────────────────

class _SettingsRow extends StatelessWidget {
  final String label;
  final String? sub;
  final String? value;
  final VoidCallback? onTap;
  final bool showChevron;
  final Color? labelColor;
  final Color? chevronColor;

  const _SettingsRow({
    required this.label,
    this.sub,
    this.value,
    this.onTap,
    this.showChevron = true,
    this.labelColor,
    this.chevronColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: AppColors.surface, width: 1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: GoogleFonts.dmSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: labelColor ?? AppColors.text,
                    ),
                  ),
                  if (sub != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 1),
                      child: Text(
                        sub!,
                        style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.text3),
                      ),
                    ),
                ],
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (value != null)
                  Padding(
                    padding: const EdgeInsets.only(right: 4),
                    child: Text(
                      value!,
                      style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.text3),
                    ),
                  ),
                if (showChevron && onTap != null)
                  Icon(
                    Icons.chevron_right,
                    size: 18,
                    color: chevronColor ?? AppColors.text3,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// SETTINGS ROW WITH TOGGLE
// ─────────────────────────────────────────────────────────────

class _SettingsRowToggle extends StatelessWidget {
  final String label;
  final String? sub;
  final bool value;
  final VoidCallback onTap;

  const _SettingsRowToggle({
    required this.label,
    this.sub,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.surface, width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppColors.text,
                  ),
                ),
                if (sub != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      sub!,
                      style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.text3),
                    ),
                  ),
              ],
            ),
          ),
          // Custom toggle
          GestureDetector(
            onTap: onTap,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 38,
              height: 22,
              decoration: BoxDecoration(
                color: value ? AppColors.primary : AppColors.border,
                borderRadius: BorderRadius.circular(11),
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 200),
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  margin: const EdgeInsets.all(2),
                  width: 18,
                  height: 18,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
