import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/alert_model.dart';
import '../../utils/formatters.dart';
import '../providers/alerts_provider.dart';

class AlertsScreen extends ConsumerWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final alerts = ref.watch(alertsProvider);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // 4.1 Header
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
              child: Text(
                'Alertas de tasa',
                style: GoogleFonts.dmSans(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text,
                ),
              ),
            ),

            // 4.3 Label + alerts list
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 10, 18, 6),
              child: Text(
                'MIS ALERTAS',
                style: GoogleFonts.dmSans(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                  color: AppColors.text3,
                ),
              ),
            ),

            if (alerts.isEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
                child: Center(
                  child: Column(
                    children: [
                      Icon(Icons.notifications_none, size: 40, color: AppColors.text3),
                      const SizedBox(height: 8),
                      Text(
                        'No tienes alertas configuradas',
                        style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.text3),
                      ),
                    ],
                  ),
                ),
              ),

            // Alert items
            ...alerts.map((alert) => _AlertItem(alert: alert)),

            // 4.4 New alert button
            _NewAlertButton(),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// ALERT ITEM
// ─────────────────────────────────────────────────────────────

class _AlertItem extends ConsumerWidget {
  final AlertModel alert;
  const _AlertItem({required this.alert});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    IconData icon;
    Color iconBg;
    Color iconColor;
    String sub;

    switch (alert.type) {
      case AlertType.up:
        icon = Icons.arrow_upward;
        iconBg = const Color(0xFFFFF0F0);
        iconColor = AppColors.primary;
        sub = 'Notificar si BCV ≥ ${alert.threshold != null ? Formatters.formatRate(alert.threshold!) : "—"}';
        break;
      case AlertType.down:
        icon = Icons.arrow_downward;
        iconBg = const Color(0xFFE8F5E9);
        iconColor = AppColors.success;
        sub = 'Notificar si BCV ≤ ${alert.threshold != null ? Formatters.formatRate(alert.threshold!) : "—"}';
        break;
      case AlertType.daily:
        icon = Icons.access_time;
        iconBg = AppColors.surface;
        iconColor = AppColors.warning;
        sub = 'Notificar cada día 6:00 PM';
        break;
    }

    return Container(
      margin: const EdgeInsets.fromLTRB(18, 0, 18, 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.surface2, width: 1.5),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Icon
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 18, color: iconColor),
          ),
          const SizedBox(width: 12),
          // Text
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  alert.label,
                  style: GoogleFonts.dmSans(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.text,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  sub,
                  style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.text3),
                ),
              ],
            ),
          ),
          // Toggle
          _CustomToggle(
            value: alert.isActive,
            onTap: () => ref.read(alertsProvider.notifier).toggle(alert.id),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// CUSTOM TOGGLE
// ─────────────────────────────────────────────────────────────

class _CustomToggle extends StatelessWidget {
  final bool value;
  final VoidCallback onTap;
  const _CustomToggle({required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 38,
        height: 22,
        decoration: BoxDecoration(
          color: value ? AppColors.primary : AppColors.border,
          borderRadius: BorderRadius.circular(11),
        ),
        child: AnimatedAlign(
          duration: const Duration(milliseconds: 200),
          alignment: value ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(
            margin: const EdgeInsets.all(2),
            width: 18,
            height: 18,
            decoration: const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// NEW ALERT BUTTON
// ─────────────────────────────────────────────────────────────

class _NewAlertButton extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return GestureDetector(
      onTap: () => _showNewAlertSheet(context, ref),
      child: Container(
        margin: const EdgeInsets.fromLTRB(18, 6, 18, 12),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: AppColors.border,
            width: 1.5,
            // Dashed border workaround: we use a simple solid border
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add, size: 16, color: AppColors.text3),
            const SizedBox(width: 8),
            Text(
              'Nueva alerta personalizada',
              style: GoogleFonts.dmSans(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: AppColors.text3,
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showNewAlertSheet(BuildContext context, WidgetRef ref) {
    AlertType selectedType = AlertType.up;
    final thresholdController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.bg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                20,
                20,
                MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nueva alerta',
                    style: GoogleFonts.dmSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.text,
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Type selector
                  Text(
                    'TIPO',
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.8,
                      color: AppColors.text3,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _TypeChip(
                        label: 'Subida',
                        isActive: selectedType == AlertType.up,
                        onTap: () => setModalState(() => selectedType = AlertType.up),
                      ),
                      const SizedBox(width: 8),
                      _TypeChip(
                        label: 'Bajada',
                        isActive: selectedType == AlertType.down,
                        onTap: () => setModalState(() => selectedType = AlertType.down),
                      ),
                      const SizedBox(width: 8),
                      _TypeChip(
                        label: 'Diaria',
                        isActive: selectedType == AlertType.daily,
                        onTap: () => setModalState(() => selectedType = AlertType.daily),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // Threshold (only if not daily)
                  if (selectedType != AlertType.daily) ...[
                    Text(
                      'UMBRAL (Bs)',
                      style: GoogleFonts.dmSans(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.8,
                        color: AppColors.text3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: thresholdController,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        hintText: 'Ej: 550.00',
                        hintStyle: GoogleFonts.dmSans(color: AppColors.text3),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                          borderSide: const BorderSide(color: AppColors.border),
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      ),
                      style: GoogleFonts.spaceMono(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.text,
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Save button
                  SizedBox(
                    width: double.infinity,
                    child: GestureDetector(
                      onTap: () {
                        double? threshold;
                        String label;

                        if (selectedType != AlertType.daily) {
                          threshold = double.tryParse(
                            thresholdController.text.replaceAll(',', '.'),
                          );
                          if (threshold == null) return;
                        }

                        switch (selectedType) {
                          case AlertType.up:
                            label = 'BCV sube de ${Formatters.formatRate(threshold!)} Bs';
                            break;
                          case AlertType.down:
                            label = 'BCV baja de ${Formatters.formatRate(threshold!)} Bs';
                            break;
                          case AlertType.daily:
                            label = 'Publicación diaria BCV';
                            break;
                        }

                        final alert = AlertModel(
                          id: DateTime.now().millisecondsSinceEpoch.toString(),
                          type: selectedType,
                          threshold: threshold,
                          label: label,
                        );
                        ref.read(alertsProvider.notifier).add(alert);
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Center(
                          child: Text(
                            'Guardar',
                            style: GoogleFonts.dmSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _TypeChip({
    required this.label,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isActive ? AppColors.primaryLgt : AppColors.surface,
            border: Border.all(
              color: isActive ? AppColors.primary : AppColors.border,
              width: 1.5,
            ),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: isActive ? AppColors.primary : AppColors.text3,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
