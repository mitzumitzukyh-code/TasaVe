import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/theme/app_colors.dart';
import '../../data/models/tasa_model.dart';
import '../../utils/formatters.dart';
import '../providers/history_provider.dart';
import '../providers/history_days_provider.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final days = ref.watch(historyDaysProvider);
    final historyAsync = ref.watch(historyProvider(days));

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          children: [
            // 3.1 Header
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Historial BCV',
                    style: GoogleFonts.dmSans(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.text,
                    ),
                  ),
                  GestureDetector(
                    onTap: () => _export(context, ref, days),
                    child: Text(
                      'Exportar',
                      style: GoogleFonts.dmSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // 3.2 Period filters
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
              child: Row(
                children: [
                  _FilterChip(label: '7 días', value: 7, currentDays: days, ref: ref),
                  const SizedBox(width: 6),
                  _FilterChip(label: '30 días', value: 30, currentDays: days, ref: ref),
                  const SizedBox(width: 6),
                  _FilterChip(label: '90 días', value: 90, currentDays: days, ref: ref),
                  const SizedBox(width: 6),
                  _FilterChip(label: '1 año', value: 365, currentDays: days, ref: ref),
                ],
              ),
            ),

            // Content
            Expanded(
              child: historyAsync.when(
                loading: () => const Center(
                  child: CircularProgressIndicator(color: AppColors.primary),
                ),
                error: (_, __) => Center(
                  child: Text(
                    'Sin datos disponibles',
                    style: GoogleFonts.dmSans(color: AppColors.text3),
                  ),
                ),
                data: (entries) {
                  if (entries.isEmpty) {
                    return Center(
                      child: Text(
                        'Sin datos disponibles',
                        style: GoogleFonts.dmSans(color: AppColors.text3),
                      ),
                    );
                  }
                  // Sort newest first for table
                  final sorted = [...entries]..sort((a, b) => b.date.compareTo(a.date));
                  // For chart: oldest first
                  final chartData = [...entries]..sort((a, b) => a.date.compareTo(b.date));

                  return ListView(
                    padding: EdgeInsets.zero,
                    children: [
                      // 3.3 Chart
                      _Chart(entries: chartData),
                      // 3.4 Stats
                      _Stats(entries: entries),
                      // 3.5 Data table
                      _DataTable(entries: sorted),
                      const SizedBox(height: 16),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _export(BuildContext context, WidgetRef ref, int days) {
    final historyAsync = ref.read(historyProvider(days));
    historyAsync.whenData((entries) {
      final buffer = StringBuffer();
      buffer.writeln('Fecha,Tasa BCV,Variación %');
      final sorted = [...entries]..sort((a, b) => b.date.compareTo(a.date));
      for (int i = 0; i < sorted.length; i++) {
        final e = sorted[i];
        final prev = i + 1 < sorted.length ? sorted[i + 1].bcvUsd : null;
        final pct = e.getVariationPct(prev);
        buffer.writeln('${Formatters.formatDateShort(e.date)},${e.bcvUsd},${pct.toStringAsFixed(2)}%');
      }
      Share.share(buffer.toString());
    });
  }
}

// ─────────────────────────────────────────────────────────────
// FILTER CHIP
// ─────────────────────────────────────────────────────────────

class _FilterChip extends StatelessWidget {
  final String label;
  final int value;
  final int currentDays;
  final WidgetRef ref;

  const _FilterChip({
    required this.label,
    required this.value,
    required this.currentDays,
    required this.ref,
  });

  @override
  Widget build(BuildContext context) {
    final isActive = currentDays == value;
    return Expanded(
      child: GestureDetector(
        onTap: () => ref.read(historyDaysProvider.notifier).state = value,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 12),
          decoration: BoxDecoration(
            color: isActive ? AppColors.primary : AppColors.surface,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Center(
            child: Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: isActive ? Colors.white : AppColors.text3,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// CHART
// ─────────────────────────────────────────────────────────────

class _Chart extends StatelessWidget {
  final List<TasaHistoryEntry> entries;
  const _Chart({required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return Container(
        margin: const EdgeInsets.fromLTRB(18, 0, 18, 12),
        height: 120,
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            'Sin datos disponibles',
            style: GoogleFonts.dmSans(color: AppColors.text3),
          ),
        ),
      );
    }

    final spots = entries.asMap().entries.map((e) {
      return FlSpot(e.key.toDouble(), e.value.bcvUsd);
    }).toList();

    return Container(
      margin: const EdgeInsets.fromLTRB(18, 0, 18, 12),
      padding: const EdgeInsets.all(14),
      height: 120 + 28,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
      ),
      child: LineChart(
        LineChartData(
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: false,
              color: AppColors.primary,
              barWidth: 2,
              dotData: FlDotData(
                show: true,
                checkToShowDot: (spot, barData) {
                  return spot == spots.last;
                },
                getDotPainter: (spot, percent, bar, index) {
                  return FlDotCirclePainter(
                    radius: 4,
                    color: AppColors.primary,
                    strokeWidth: 0,
                  );
                },
              ),
              belowBarData: BarAreaData(
                show: true,
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    AppColors.primary.withValues(alpha: 0.15),
                    AppColors.primary.withValues(alpha: 0.0),
                  ],
                ),
              ),
            ),
          ],
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          gridData: const FlGridData(show: false),
          lineTouchData: const LineTouchData(enabled: false),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// STATS
// ─────────────────────────────────────────────────────────────

class _Stats extends StatelessWidget {
  final List<TasaHistoryEntry> entries;
  const _Stats({required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) return const SizedBox.shrink();

    final values = entries.map((e) => e.bcvUsd).toList();
    final minVal = values.reduce(math.min);
    final maxVal = values.reduce(math.max);
    final avgVal = values.reduce((a, b) => a + b) / values.length;

    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
      child: Row(
        children: [
          _StatBox(label: 'MÍNIMO', value: minVal, color: AppColors.success),
          const SizedBox(width: 8),
          _StatBox(label: 'PROMEDIO', value: avgVal, color: AppColors.text),
          const SizedBox(width: 8),
          _StatBox(label: 'MÁXIMO', value: maxVal, color: AppColors.error),
        ],
      ),
    );
  }
}

class _StatBox extends StatelessWidget {
  final String label;
  final double value;
  final Color color;
  const _StatBox({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: GoogleFonts.dmSans(
                fontSize: 10,
                fontWeight: FontWeight.w700,
                color: AppColors.text3,
                letterSpacing: 0.6,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              Formatters.formatRate(value),
              style: GoogleFonts.spaceMono(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
// DATA TABLE
// ─────────────────────────────────────────────────────────────

class _DataTable extends StatelessWidget {
  final List<TasaHistoryEntry> entries;
  const _DataTable({required this.entries});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 0, 18, 14),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.surface2),
        borderRadius: BorderRadius.circular(10),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          // Header row
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'FECHA',
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: AppColors.text3,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
                Expanded(
                  child: Text(
                    'TASA BCV',
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: AppColors.text3,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
                Expanded(
                  child: Text(
                    'VARIACIÓN',
                    textAlign: TextAlign.right,
                    style: GoogleFonts.dmSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: AppColors.text3,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Data rows
          ...entries.asMap().entries.map((entry) {
            final i = entry.key;
            final e = entry.value;
            final prev = i + 1 < entries.length ? entries[i + 1].bcvUsd : null;
            final hasPrev = prev != null;
            final pct = hasPrev ? e.getVariationPct(prev) : null;

            return Container(
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: AppColors.surface2, width: 1),
                ),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      Formatters.formatDateShort(e.date),
                      style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.text),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      Formatters.formatRate(e.bcvUsd),
                      style: GoogleFonts.spaceMono(fontSize: 11, color: AppColors.text),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      pct != null ? Formatters.formatVariation(pct) : '—',
                      textAlign: TextAlign.right,
                      style: GoogleFonts.spaceMono(
                        fontSize: 11,
                        color: pct == null
                            ? AppColors.text3
                            : pct >= 0
                                ? AppColors.success
                                : AppColors.error,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}
